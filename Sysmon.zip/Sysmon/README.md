# Detection Cloud's Microsoft Sysmon Configuration File


## Simple Sysmon install
Run with administrator rights

  `sysmon.exe -accepteula -i DC_SysmonConfig.xml`

## Update existing configuration
Run with administrator rights

  `sysmon.exe -c DC_SysmonConfig.xml`

## Uninstall Sysmon
Run with administrator rights

  `sysmon.exe -u`

## Managing Sysmon Config with Group Policy
https://blogs.technet.microsoft.com/motiba/2017/12/07/sysinternals-sysmon-suspicious-activity-guide/

## Additional Reference
https://docs.microsoft.com/en-us/sysinternals/downloads/sysmon

### Please email detectioncloud@salesforce.com with any questions and/or for configuration guidance
